package com.goat.iptv

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RowVH(val tv: TextView) : RecyclerView.ViewHolder(tv)

class RowAdapter<T>(
    private val label: (T) -> String,
    private val onClick: (T) -> Unit,
    private val onLong: ((T) -> Unit)? = null
) : RecyclerView.Adapter<RowVH>() {

    var items: List<T> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowVH {
        val tv = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_row, parent, false) as TextView
        return RowVH(tv)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: RowVH, position: Int) {
        val item = items[position]
        holder.tv.text = label(item)
        holder.tv.setOnClickListener { onClick(item) }
        holder.tv.setOnLongClickListener {
            onLong?.invoke(item)
            onLong != null
        }
    }
}
