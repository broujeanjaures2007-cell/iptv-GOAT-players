package com.goat.iptv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Store(ctx: Context) {
    private val app = ctx.applicationContext
    private val sp = app.getSharedPreferences("goat", Context.MODE_PRIVATE)
    private val dir: File = app.filesDir

    // ---------- sources ----------
    fun sources(): MutableList<Source> {
        val arr = JSONArray(sp.getString("sources", "[]"))
        val l = ArrayList<Source>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            l.add(
                Source(
                    o.getString("id"), o.getString("name"), o.getString("type"),
                    o.getString("url"), o.optString("user"), o.optString("pass")
                )
            )
        }
        return l
    }

    private fun saveSources(l: List<Source>) {
        val arr = JSONArray()
        for (s in l) {
            val o = JSONObject()
            o.put("id", s.id)
            o.put("name", s.name)
            o.put("type", s.type)
            o.put("url", s.url)
            o.put("user", s.user)
            o.put("pass", s.pass)
            arr.put(o)
        }
        sp.edit().putString("sources", arr.toString()).apply()
    }

    fun addSource(s: Source) {
        val l = sources()
        l.add(s)
        saveSources(l)
    }

    fun removeSource(id: String) {
        saveSources(sources().filter { it.id != id })
        File(dir, "ch_$id.json").delete()
        sp.edit()
            .remove("fav_$id").remove("hid_$id").remove("ren_$id")
            .remove("ord_$id").remove("rec_$id").apply()
    }

    // ---------- sets ----------
    private fun getSet(k: String): MutableSet<String> {
        val s = sp.getStringSet(k, null)
        return if (s == null) HashSet() else HashSet(s)
    }

    private fun putSet(k: String, v: Set<String>) {
        sp.edit().putStringSet(k, v).apply()
    }

    // ---------- favoris ----------
    fun favorites(sid: String): Set<String> = getSet("fav_$sid")

    fun toggleFav(sid: String, chId: String): Boolean {
        val s = getSet("fav_$sid")
        val added = s.add(chId)
        if (!added) s.remove(chId)
        putSet("fav_$sid", s)
        return added
    }

    // ---------- menu perso : masquees / renommees / ordre ----------
    fun hidden(sid: String): Set<String> = getSet("hid_$sid")

    fun setHidden(sid: String, g: String, hide: Boolean) {
        val s = getSet("hid_$sid")
        if (hide) s.add(g) else s.remove(g)
        putSet("hid_$sid", s)
    }

    fun renames(sid: String): Map<String, String> {
        val o = JSONObject(sp.getString("ren_$sid", "{}"))
        val m = HashMap<String, String>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            m[k] = o.getString(k)
        }
        return m
    }

    fun setRename(sid: String, cat: String, newName: String) {
        val m = HashMap<String, String>(renames(sid))
        if (newName.isBlank()) m.remove(cat) else m[cat] = newName
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        sp.edit().putString("ren_$sid", o.toString()).apply()
    }

    fun order(sid: String): List<String> {
        val a = JSONArray(sp.getString("ord_$sid", "[]"))
        val l = ArrayList<String>()
        for (i in 0 until a.length()) l.add(a.getString(i))
        return l
    }

    fun saveOrder(sid: String, l: List<String>) {
        val a = JSONArray()
        for (s in l) a.put(s)
        sp.edit().putString("ord_$sid", a.toString()).apply()
    }

    fun resetMenu(sid: String) {
        sp.edit().remove("hid_$sid").remove("ren_$sid").remove("ord_$sid").apply()
    }

    // ---------- recents ----------
    fun recents(sid: String): List<String> {
        val a = JSONArray(sp.getString("rec_$sid", "[]"))
        val l = ArrayList<String>()
        for (i in 0 until a.length()) l.add(a.getString(i))
        return l
    }

    fun addRecent(sid: String, chId: String) {
        val l = ArrayList<String>(recents(sid))
        l.remove(chId)
        l.add(0, chId)
        while (l.size > 30) l.removeAt(l.size - 1)
        val a = JSONArray()
        for (s in l) a.put(s)
        sp.edit().putString("rec_$sid", a.toString()).apply()
    }

    // ---------- cache des chaines ----------
    fun saveChannels(sid: String, list: List<Channel>) {
        val a = JSONArray()
        for (c in list) {
            val o = JSONObject()
            o.put("n", c.name)
            o.put("u", c.url)
            o.put("l", c.logo)
            o.put("g", c.group)
            a.put(o)
        }
        File(dir, "ch_$sid.json").writeText(a.toString())
    }

    fun loadChannels(sid: String): List<Channel>? {
        val f = File(dir, "ch_$sid.json")
        if (!f.exists()) return null
        return try {
            val a = JSONArray(f.readText())
            val l = ArrayList<Channel>(a.length())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                l.add(Channel(o.getString("n"), o.getString("u"), o.optString("l"), o.optString("g")))
            }
            l
        } catch (e: Exception) {
            null
        }
    }
}
