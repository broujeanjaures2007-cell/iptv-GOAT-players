package com.goat.iptv

data class Source(
    val id: String,
    val name: String,
    val type: String, // "m3u" ou "xtream"
    val url: String,
    val user: String,
    val pass: String
)

data class Channel(
    val name: String,
    val url: String,
    val logo: String,
    val group: String
)

object Session {
    var list: List<Channel> = emptyList()
    var index: Int = 0
    var sid: String = ""
}
