package com.goat.iptv

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var info: TextView
    private lateinit var msg: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val hideInfo = Runnable { info.visibility = View.GONE }
    private var attempt = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.player)
        info = findViewById(R.id.info)
        msg = findViewById(R.id.msg)

        if (Session.list.isEmpty()) {
            finish()
            return
        }

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 9) IPTVGoat/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
        player = p
        playerView.player = p
        playerView.setOnClickListener { showInfo() }

        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    msg.visibility = View.GONE
                } else if (playbackState == Player.STATE_BUFFERING) {
                    msg.text = "Chargement..."
                    msg.visibility = View.VISIBLE
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                retryOrFail()
            }
        })

        playCurrent()
    }

    private fun current(): Channel? = Session.list.getOrNull(Session.index)

    private fun playCurrent() {
        val ch = current() ?: return
        attempt = 0
        Store(this).addRecent(Session.sid, ch.url)
        info.text = (Session.index + 1).toString() + ". " + ch.name
        showInfo()
        msg.text = "Chargement..."
        msg.visibility = View.VISIBLE
        startAttempt(ch.url)
    }

    private fun startAttempt(url: String) {
        val finalUrl = if (attempt == 2) url.replace(".m3u8", ".ts") else url
        val b = MediaItem.Builder().setUri(finalUrl)
        if (attempt == 1) b.setMimeType(MimeTypes.APPLICATION_M3U8)
        val p = player ?: return
        p.setMediaItem(b.build())
        p.prepare()
        p.playWhenReady = true
    }

    private fun retryOrFail() {
        val ch = current() ?: return
        val hasM3u8 = ch.url.contains(".m3u8")
        val next = if (attempt == 0) (if (hasM3u8) 2 else 1) else -1
        if (next == -1) {
            msg.text = "Flux indisponible. Haut/Bas pour changer de chaine."
            msg.visibility = View.VISIBLE
        } else {
            attempt = next
            startAttempt(ch.url)
        }
    }

    private fun showInfo() {
        info.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        handler.postDelayed(hideInfo, 4000)
    }

    private fun zap(delta: Int) {
        val n = Session.index + delta
        if (n < 0 || n >= Session.list.size) return
        Session.index = n
        playCurrent()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    zap(-1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_UP -> {
                    zap(1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    showInfo()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.playWhenReady = false
    }

    override fun onDestroy() {
        handler.removeCallbacks(hideInfo)
        player?.release()
        player = null
        super.onDestroy()
    }
}
