package com.goat.iptv

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var adapter: RowAdapter<Source>
    private lateinit var empty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        empty = findViewById(R.id.empty)

        adapter = RowAdapter<Source>(
            label = { s -> s.name + "   (" + (if (s.type == "xtream") "Xtream" else "M3U") + ")" },
            onClick = { s ->
                startActivity(Intent(this, BrowseActivity::class.java).putExtra("sid", s.id))
            },
            onLong = { s -> confirmDelete(s) }
        )
        val rv = findViewById<RecyclerView>(R.id.list)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        findViewById<Button>(R.id.btnAdd).setOnClickListener { addSource() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val l = store.sources()
        adapter.items = l
        empty.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmDelete(s: Source) {
        AlertDialog.Builder(this)
            .setTitle("Supprimer " + s.name + " ?")
            .setPositiveButton("Supprimer") { _, _ ->
                store.removeSource(s.id)
                refresh()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun addSource() {
        AlertDialog.Builder(this)
            .setTitle("Type de source")
            .setItems(arrayOf("Lien M3U / M3U8", "Xtream Codes")) { _, which ->
                if (which == 0) {
                    form("Playlist M3U", listOf("Nom", "Lien M3U (http...)")) { v ->
                        save("m3u", v[0], v[1], "", "")
                    }
                } else {
                    form(
                        "Xtream Codes",
                        listOf("Nom", "Serveur (http://host:port)", "Utilisateur", "Mot de passe")
                    ) { v -> save("xtream", v[0], v[1], v[2], v[3]) }
                }
            }
            .show()
    }

    private fun form(title: String, hints: List<String>, onOk: (List<String>) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(48, 24, 48, 0)
        val edits = ArrayList<EditText>()
        for (h in hints) {
            val e = EditText(this)
            e.hint = h
            e.setSingleLine()
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            box.addView(e)
            edits.add(e)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ -> onOk(edits.map { it.text.toString().trim() }) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun save(type: String, name: String, url: String, user: String, pass: String) {
        if (url.isBlank()) {
            Toast.makeText(this, "Lien / serveur manquant", Toast.LENGTH_SHORT).show()
            return
        }
        val u = if (url.startsWith("http")) url else "http://$url"
        store.addSource(
            Source(
                System.currentTimeMillis().toString(),
                name.ifBlank { "Ma source" },
                type, u, user, pass
            )
        )
        refresh()
    }
}
