package com.goat.iptv

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Loader {

    private const val UA = "Mozilla/5.0 (Linux; Android 9) IPTVGoat/1.0"

    fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun load(s: Source): List<Channel> =
        if (s.type == "xtream") loadXtream(s) else parseM3u(http(s.url))

    fun parseM3u(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        val attr = Regex("([a-zA-Z0-9_-]+)=\"([^\"]*)\"")
        var name = ""
        var logo = ""
        var group = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF")) {
                val attrs = attr.findAll(line).associate {
                    it.groupValues[1].lowercase() to it.groupValues[2]
                }
                logo = attrs["tvg-logo"] ?: ""
                group = attrs["group-title"] ?: ""
                name = line.substringAfterLast(",", "").trim()
                if (name.isEmpty()) name = attrs["tvg-name"] ?: ""
            } else if (line.startsWith("#EXTGRP:")) {
                if (group.isEmpty()) group = line.removePrefix("#EXTGRP:").trim()
            } else if (!line.startsWith("#")) {
                out.add(
                    Channel(
                        if (name.isEmpty()) line else name,
                        line,
                        logo,
                        if (group.isEmpty()) "Sans categorie" else group
                    )
                )
                name = ""
                logo = ""
                group = ""
            }
        }
        return out
    }

    fun loadXtream(s: Source): List<Channel> {
        val base = s.url.trimEnd('/')
        val u = URLEncoder.encode(s.user, "UTF-8")
        val p = URLEncoder.encode(s.pass, "UTF-8")
        val api = "$base/player_api.php?username=$u&password=$p"

        val cats = JSONArray(http("$api&action=get_live_categories"))
        val catMap = HashMap<String, String>()
        for (i in 0 until cats.length()) {
            val o = cats.getJSONObject(i)
            catMap[o.optString("category_id")] = o.optString("category_name")
        }

        val streams = JSONArray(http("$api&action=get_live_streams"))
        val out = ArrayList<Channel>(streams.length())
        for (i in 0 until streams.length()) {
            val o = streams.getJSONObject(i)
            val id = o.optString("stream_id")
            val url = "$base/live/${s.user}/${s.pass}/$id.m3u8"
            out.add(
                Channel(
                    o.optString("name"),
                    url,
                    o.optString("stream_icon"),
                    catMap[o.optString("category_id")] ?: "Sans categorie"
                )
            )
        }
        return out
    }
}
