package com.goat.iptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class BrowseActivity : AppCompatActivity() {

    // kind : 0 = favoris, 1 = recents, 2 = toutes, 3 = categorie
    class Cat(val kind: Int, val key: String, val label: String)

    private lateinit var store: Store
    private lateinit var sid: String
    private lateinit var source: Source

    private var channels: List<Channel> = emptyList()
    private var shown: List<Channel> = emptyList()
    private var favs: Set<String> = emptySet()
    private var renames: Map<String, String> = emptyMap()
    private var showHidden = false

    private lateinit var statusView: TextView
    private lateinit var catRv: RecyclerView
    private lateinit var chanRv: RecyclerView
    private lateinit var catAdapter: RowAdapter<Cat>
    private lateinit var chanAdapter: RowAdapter<Channel>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)
        store = Store(this)

        val id = intent.getStringExtra("sid")
        if (id == null) {
            finish()
            return
        }
        sid = id
        val s = store.sources().firstOrNull { it.id == sid }
        if (s == null) {
            finish()
            return
        }
        source = s
        favs = store.favorites(sid)

        findViewById<TextView>(R.id.title).text = source.name
        statusView = findViewById(R.id.status)
        catRv = findViewById(R.id.cats)
        chanRv = findViewById(R.id.chans)

        catAdapter = RowAdapter<Cat>(
            label = { c -> c.label },
            onClick = { c -> openCat(c) },
            onLong = { c -> if (c.kind == 3) catOptions(c) }
        )
        chanAdapter = RowAdapter<Channel>(
            label = { ch -> (if (ch.url in favs) "★ " else "") + ch.name },
            onClick = { ch -> play(ch) },
            onLong = { ch -> toggleFav(ch) }
        )
        catRv.layoutManager = LinearLayoutManager(this)
        catRv.adapter = catAdapter
        chanRv.layoutManager = LinearLayoutManager(this)
        chanRv.adapter = chanAdapter

        findViewById<Button>(R.id.btnRefresh).setOnClickListener { load(true) }
        findViewById<Button>(R.id.btnMenu).setOnClickListener { openMenu() }

        load(false)
    }

    private fun setStatus(t: String?) {
        statusView.visibility = if (t == null) View.GONE else View.VISIBLE
        statusView.text = t ?: ""
    }

    private fun load(force: Boolean) {
        setStatus("Chargement de la playlist...")
        thread {
            try {
                val cached = if (force) null else store.loadChannels(sid)
                val result: List<Channel>
                if (cached != null) {
                    result = cached
                } else {
                    result = Loader.load(source)
                    store.saveChannels(sid, result)
                }
                runOnUiThread {
                    channels = result
                    setStatus(if (result.isEmpty()) "Aucune chaine trouvee." else null)
                    refreshCats()
                }
            } catch (e: Exception) {
                runOnUiThread { setStatus("Erreur : " + e.message) }
            }
        }
    }

    private fun sortedGroups(): List<String> {
        val order = store.order(sid)
        return channels.map { it.group }.distinct().sortedBy {
            val i = order.indexOf(it)
            if (i < 0) Int.MAX_VALUE else i
        }
    }

    private fun refreshCats() {
        renames = store.renames(sid)
        val hidden = store.hidden(sid)
        val counts = channels.groupingBy { it.group }.eachCount()
        val cats = ArrayList<Cat>()
        cats.add(Cat(0, "", "★ Favoris"))
        cats.add(Cat(1, "", "Recents"))
        cats.add(Cat(2, "", "Toutes les chaines (" + channels.size + ")"))
        for (g in sortedGroups()) {
            val isHidden = g in hidden
            if (isHidden && !showHidden) continue
            val name = renames[g] ?: g
            val suffix = if (isHidden) "  [masquee]" else ""
            cats.add(Cat(3, g, name + " (" + (counts[g] ?: 0) + ")" + suffix))
        }
        catAdapter.items = cats
    }

    private fun openCat(c: Cat) {
        val list: List<Channel> = when (c.kind) {
            0 -> channels.filter { it.url in favs }
            1 -> {
                val rec = store.recents(sid)
                rec.mapNotNull { u -> channels.firstOrNull { it.url == u } }
            }
            2 -> channels
            else -> channels.filter { it.group == c.key }
        }
        shown = list
        chanAdapter.items = list
        chanRv.scrollToPosition(0)
        chanRv.post { chanRv.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    private fun play(ch: Channel) {
        Session.list = shown
        Session.index = shown.indexOfFirst { it === ch }.coerceAtLeast(0)
        Session.sid = sid
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun toggleFav(ch: Channel) {
        val added = store.toggleFav(sid, ch.url)
        favs = store.favorites(sid)
        Toast.makeText(
            this,
            if (added) "Ajoutee aux favoris" else "Retiree des favoris",
            Toast.LENGTH_SHORT
        ).show()
        val idx = shown.indexOfFirst { it === ch }
        if (idx >= 0) chanAdapter.notifyItemChanged(idx)
    }

    // ---------- menu perso ----------
    private fun catOptions(c: Cat) {
        val isHidden = c.key in store.hidden(sid)
        val opts = arrayOf("Renommer", if (isHidden) "Afficher" else "Masquer", "Monter", "Descendre")
        AlertDialog.Builder(this)
            .setTitle(renames[c.key] ?: c.key)
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> rename(c)
                    1 -> {
                        store.setHidden(sid, c.key, !isHidden)
                        refreshCats()
                    }
                    2 -> move(c.key, -1)
                    3 -> move(c.key, 1)
                }
            }
            .show()
    }

    private fun rename(c: Cat) {
        val et = EditText(this)
        et.setText(renames[c.key] ?: c.key)
        et.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Renommer")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                store.setRename(sid, c.key, et.text.toString().trim())
                refreshCats()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun move(g: String, delta: Int) {
        val hidden = store.hidden(sid)
        val all = sortedGroups().toMutableList()
        val visible = all.filter { showHidden || it !in hidden }
        val vi = visible.indexOf(g)
        val vj = vi + delta
        if (vi < 0 || vj < 0 || vj >= visible.size) return
        val i = all.indexOf(g)
        val j = all.indexOf(visible[vj])
        all.removeAt(i)
        all.add(j, g)
        store.saveOrder(sid, all)
        refreshCats()
    }

    private fun openMenu() {
        val opts = arrayOf(
            if (showHidden) "Cacher les categories masquees" else "Voir les categories masquees",
            "Reinitialiser mon menu (ordre, noms, masquees)"
        )
        AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(opts) { _, which ->
                if (which == 0) {
                    showHidden = !showHidden
                    refreshCats()
                } else {
                    store.resetMenu(sid)
                    refreshCats()
                }
            }
            .show()
    }
}
